<footer class="main-footer">
    <div class="footer-left">
        <h5>RMP @copyright  LanternTech</h5>
    </div>
  </footer><?php /**PATH D:\kuliah\laragon\presensi-satpam\resources\views/components/footer.blade.php ENDPATH**/ ?>