<!--Modal Tambah Data-->
<?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" tabindex="-1" role="dialog" id="updateDataStatus<?php echo e($shift->id); ?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Shift</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                <div class="modal-body">
                    <p>Apakah anda yakin ingin mengubah status dari <?php echo e($shift->name); ?>?</p>
                </div>
                <div class="modal-footer bg-whitesmoke br">
                    <a type="button" href="<?php echo e(url('/admin/data-shift/'.$shift->id.'/update-status')); ?>"
                        style="transform: translateX(-80%); width: 174px; border-radius: 30px; background-color: #4285F4;"
                        class="btn text-white">Update Shift</a>
                </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\kuliah\laragon\presensi-satpam\resources\views/pages/admin/modal/update-shift-status.blade.php ENDPATH**/ ?>