

<?php $__env->startSection('title', 'Dashboard Superadmin'); ?>


<?php $__env->startSection('main-content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-warning alert-dismissible show fade">
            <div class="alert-body">
                <button class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
                <?php echo e($error); ?>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session('status')): ?>
        <div class="alert alert-info alert-dismissible show fade">
            <div class="alert-body">
                <button class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
                <?php echo e(session('status')); ?>

            </div>
        </div>
        <?php endif; ?>
        <div class="section-header">
            <h1>PT. Rusyida Mitra Perkasa</h1>
        </div>
        <div class="row">
            <div class="col-lg-7 col-md-12 col-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="border-radius: 30px;" class="input-group-text">
                            <input style="border: none;" type="text" class="form-control" placeholder="Search"
                                aria-label="Search">
                            <button class="btn btn-light" type="button"><i style="right: 70px;"
                                    class="fas fa-search"></i></button>
                        </div>
                        <!-- <div class="card-header-action">
                    <a href="#" class="btn btn-danger">View More <i class="fas fa-chevron-right"></i></a>
                  </div> -->
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-md">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">NIK</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($u->name); ?></td>
                                        <td><?php echo e($u->nik); ?></td>
                                        <td><?php echo e($u->email); ?></td>
                                        <td>
                                            <span class="badge badge-success">Aktif</span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row justify-content-center">
                            <div class="buttons">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li
                                            class="<?php echo e(($users->currentPage() == 1) ? 'page-item disabled' : 'page-item'); ?>">
                                            <a class="page-link" href="<?php echo e($users->url($users->currentPage()-1)); ?>"
                                                aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                        </li>
                                        <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                                            <li
                                                class="<?php echo e(($users->currentPage() == $i) ? 'page-item active' : 'page-item'); ?>">
                                                <a class="page-link" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a></li>
                                            <?php endfor; ?>
                                            <li
                                                class="<?php echo e(($users->currentPage() == $users->lastPage()) ? 'page-item disabled' : 'page-item'); ?>">
                                                <a class="page-link" href="<?php echo e($users->url($users->currentPage()+1)); ?>"
                                                    aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 style="color: black;">Buka Presensi</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('/admin/')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Shift <code></code></label>
                                <select class="form-control form-control-lg" name="shiftID">
                                    <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($shift->id); ?>"><?php echo e($shift->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="text-center pt-1 pb-1">
                                <button type="submit" class="btn btn-light btn-lg btn-round">
                                    Buka Presensi
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h4 style="color: black;">Presensi</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-md">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Presensi</th>
                                        <th scope="col">Start</th>
                                        <th scope="col">End</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($u->name); ?></td>
                                        <td><?php echo e($u->start_time); ?></td>
                                        <td><?php echo e($u->end_time); ?></td>
                                        <td>
                                            <?php if($u->status == 'ACTIVE'): ?>
                                            <span class="badge badge-success">Aktif</span>
                                            <?php else: ?>
                                            <span class="badge badge-danger">Nonaktif</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row justify-content-center">
                            <div class="buttons">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li
                                            class="<?php echo e(($presensi->currentPage() == 1) ? 'page-item disabled' : 'page-item'); ?>">
                                            <a class="page-link" href="<?php echo e($presensi->url($presensi->currentPage()-1)); ?>"
                                                aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                        </li>
                                        <?php for($i = 1; $i <= $presensi->lastPage(); $i++): ?>
                                            <li
                                                class="<?php echo e(($presensi->currentPage() == $i) ? 'page-item active' : 'page-item'); ?>">
                                                <a class="page-link" href="<?php echo e($presensi->url($i)); ?>"><?php echo e($i); ?></a></li>
                                            <?php endfor; ?>
                                            <li
                                                class="<?php echo e(($presensi->currentPage() == $presensi->lastPage()) ? 'page-item disabled' : 'page-item'); ?>">
                                                <a class="page-link"
                                                    href="<?php echo e($presensi->url($presensi->currentPage()+1)); ?>"
                                                    aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\presensi-satpam\resources\views/pages/admin/SuperAdmin-Dashboard.blade.php ENDPATH**/ ?>