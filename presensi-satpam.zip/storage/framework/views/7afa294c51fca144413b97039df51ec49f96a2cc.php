<!--Modal Tambah Data-->
<div class="modal fade" tabindex="-1" role="dialog" id="addData">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Titik Lokasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="<?php echo e(url('/admin/data-lokasi')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="form-group">
                            <label>Nama Titik</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <i class="fas fa-pencil-alt"></i>
                                    </div>
                                </div>
                                <input type="text" class="form-control" placeholder="Nama" name="name">
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-group">
                            <label for="">
                                <h5><b>Google Maps</b></h5>
                            </label>
                            <input type="text" id="lat" name="latitude"
                                placeholder="Masukkan Koordinat Latitude" class="form-control" autofocus
                                data-parsley-required="true">
                            
                            <input type="text" id="lng" name="longitude"
                                placeholder="Masukkan Koordinat Longitude" class="form-control" autofocus
                                data-parsley-required="true">
                            
                        </div>
                        <div id="map" style="height:400px; width: 450px;" class="my-3"></div>
                    </div>
                </div>
                <div class="modal-footer bg-whitesmoke br">
                    <button type="submit"
                        style="transform: translateX(-80%); width: 174px; border-radius: 30px; background-color: #4285F4;"
                        class="btn text-white">Simpan Lokasi</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\kuliah\laragon\presensi-satpam\resources\views/pages/admin/modal/create-location.blade.php ENDPATH**/ ?>