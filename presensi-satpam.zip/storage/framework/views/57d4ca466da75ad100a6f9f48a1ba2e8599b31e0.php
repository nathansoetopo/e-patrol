<footer class="main-footer">
    <div class="footer-left">
        <h1>SIUUU Fix Goall</h1>
    </div>
    <div class="footer-right">
        <h1>Mase CR7</h1>
    </div>
  </footer><?php /**PATH C:\laragon\www\presensi-satpam\resources\views/components/footer.blade.php ENDPATH**/ ?>