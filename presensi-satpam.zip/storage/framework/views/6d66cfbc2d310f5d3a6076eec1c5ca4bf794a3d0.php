

<?php $__env->startSection('title','Data Shift'); ?>

<?php $__env->startSection('main-content'); ?>

<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-warning alert-dismissible show fade">
            <div class="alert-body">
                <button class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
                <?php echo e($error); ?>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session('status')): ?>
        <div class="alert alert-info alert-dismissible show fade">
            <div class="alert-body">
                <button class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
                <?php echo e(session('status')); ?>

            </div>
        </div>
        <?php endif; ?>
        <div class="section-header">
            <h1>Data Shift</h1>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="border-radius: 30px;" class="input-group-text">
                            <input style="border: none;" type="text" class="form-control" id="search" placeholder="Search"
                                aria-label="Search">
                            <button class="btn btn-light" type="button"><i style="right: 70px;"
                                    class="fas fa-search"></i></button>
                        </div>
                        <div class="col-lg-8">

                        </div>
                        <div style="border-radius: 30px; position: absolute; object-position: center; left: 84%;">
                            <button style="padding-top: 2%; padding-bottom: 2%;" data-toggle="modal"
                                data-target="#addData" class="btn btn-light" type="button">Tambah Shift <i
                                    class="fas fa-plus"></i></button>
                        </div>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-md">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Start</th>
                                        <th scope="col">End</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="tbody">
                                    <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($shift->name); ?></td>
                                        <td><?php echo e($shift->start_time); ?></td>
                                        <td><?php echo e($shift->end_time); ?></td>
                                        <td>
                                            <?php if($shift->status == 'ACTIVE'): ?>
                                            <span class="badge badge-success">Aktif</span>
                                            <?php else: ?>
                                            <span class="badge badge-danger">Nonaktif</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('/admin/data-shift/'.$shift->id.'/data-satpam')); ?>" id="modal-7"
                                                class="btn btn-transparent text-center text-dark">
                                                <i class="fas fa-user-cog fa-2x"></i>
                                            </a>
                                            <a href="<?php echo e(url('/admin/data-shift/'.$shift->id.'/data-hrd')); ?>" id="modal-7"
                                                class="btn btn-transparent text-center text-dark">
                                                <i class="fas fa-user-shield fa-2x"></i>
                                            </a>
                                            <a href="#" id="modal-7" data-toggle="modal" data-target="#updateData<?php echo e($shift->id); ?>"
                                                class="btn btn-transparent text-center text-dark">
                                                <i class="fas fa-edit fa-2x"></i>
                                            </a>
                                            <a href="#" id="modal-7" data-toggle="modal" data-target="#updateDataStatus<?php echo e($shift->id); ?>"
                                                class="btn btn-transparent text-center text-dark">
                                                <i class="fas fa-power-off fa-2x"></i>
                                            </a>
                                            <a href="#" id="modal-7" data-toggle="modal" data-target="#deleteData<?php echo e($shift->id); ?>"
                                                class="btn btn-transparent text-center text-dark">
                                            <i class="fas fa-trash-alt fa-2x"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row justify-content-center">
                            <div class="buttons">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li
                                            class="<?php echo e(($shifts->currentPage() == 1) ? 'page-item disabled' : 'page-item'); ?>">
                                            <a class="page-link" href="<?php echo e($shifts->url($shifts->currentPage()-1)); ?>"
                                                aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                                <span class="sr-only">Previous</span>
                                            </a>
                                        </li>
                                        <?php for($i = 1; $i <= $shifts->lastPage(); $i++): ?>
                                            <li
                                                class="<?php echo e(($shifts->currentPage() == $i) ? 'page-item active' : 'page-item'); ?>">
                                                <a class="page-link" href="<?php echo e($shifts->url($i)); ?>"><?php echo e($i); ?></a></li>
                                            <?php endfor; ?>
                                            <li
                                                class="<?php echo e(($shifts->currentPage() == $shifts->lastPage()) ? 'page-item disabled' : 'page-item'); ?>">
                                                <a class="page-link"
                                                    href="<?php echo e($shifts->url($shifts->currentPage()+1)); ?>"
                                                    aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                    <span class="sr-only">Next</span>
                                                </a>
                                            </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
</div>
</div>
</section>

<?php echo $__env->make('pages.admin.modal.create-shift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.admin.modal.update-shift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.admin.modal.update-shift-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pages.admin.modal.delete-shift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Script Search-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script>  
    function fetch_user_data(query = '')
    {
      $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
       url:"<?php echo e(url('/search-shift')); ?>",
       method:'POST',
       data:{query:query},
       success:function(response)
       {
        $('#tbody').html(response);
       }
      })
    }
    $(document).on('keyup', '#search', function(){
      var word = $(this).val();
      fetch_user_data(word);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laragon\presensi-satpam\resources\views/pages/admin/SuperAdmin-DataShift.blade.php ENDPATH**/ ?>