<footer class="main-footer">
    <div class="footer-left">
        <h5>RMP @copyright LanternTech</h5>
    </div>
  </footer>